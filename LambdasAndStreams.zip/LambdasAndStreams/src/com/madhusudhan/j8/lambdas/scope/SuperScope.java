package com.madhusudhan.j8.lambdas.scope;

public class SuperScope {

	final String member = "GODFATHER";
}
