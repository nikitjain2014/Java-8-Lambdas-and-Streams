package com.madhusudhan.j8.functions.intro;

public class Patient {

}
