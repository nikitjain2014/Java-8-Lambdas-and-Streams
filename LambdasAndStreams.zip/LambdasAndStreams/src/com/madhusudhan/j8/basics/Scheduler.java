package com.madhusudhan.j8.basics;

public interface Scheduler {

	void schedule();
}
